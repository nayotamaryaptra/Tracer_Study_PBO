from django.apps import AppConfig


class StatistikConfig(AppConfig):
    name = "statistik"
