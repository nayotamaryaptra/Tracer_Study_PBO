from django.shortcuts import render
from django.contrib.auth.decorators import login_required, user_passes_test
from django.db.models import Count, Avg, Max
from django.http import HttpResponse
from alumni.models import Alumni, Prodi
from survey.models import Survey

# Library Standard ReportLab
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet

# Library Grafik ReportLab (Baru)
from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.piecharts import Pie
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.lib.units import inch

import io
import datetime

def is_admin(user):
    return user.is_staff or user.is_superuser

# --- Helper Function untuk Hitung Data (Supaya tidak duplikasi kode) ---
def get_statistik_data(tahun_filter=None):
    alumni_qs = Alumni.objects.all()
    if tahun_filter:
        alumni_qs = alumni_qs.filter(tahun_lulus=tahun_filter)

    # 1. Data Status Bekerja
    stats_bekerja = alumni_qs.values('status_bekerja').annotate(total=Count('id'))
    # Default: [Bekerja, Belum]
    count_bekerja = 0
    count_belum = 0
    for item in stats_bekerja:
        if item['status_bekerja']:
            count_bekerja = item['total']
        else:
            count_belum = item['total']
            
    # 2. Data Kesesuaian (Top 5 biar grafik muat)
    survey_qs = Survey.objects.filter(alumni__in=alumni_qs)
    stats_kesesuaian = survey_qs.values('kesesuaian').annotate(total=Count('id')).order_by('-total')[:5]
    
    label_kesesuaian = [item['kesesuaian'] for item in stats_kesesuaian]
    data_kesesuaian = [item['total'] for item in stats_kesesuaian]

    return {
        'pie_data': [count_bekerja, count_belum], # [Hijau, Merah]
        'bar_labels': label_kesesuaian,
        'bar_data': data_kesesuaian
    }

@login_required
def statistik_dashboard(request):
    # --- LOGIC MAHASISWA (Simple Motivational View) ---
    if not request.user.is_staff:
        # 1. Grafik Tren Global (Bekerja vs Belum)
        stats_bekerja = Alumni.objects.values('status_bekerja').annotate(total=Count('id'))
        pie_data = [0, 0] # [Bekerja, Belum]
        for item in stats_bekerja:
            if item['status_bekerja']: pie_data[0] = item['total']
            else: pie_data[1] = item['total']

        # 2. Ranking Gaji Global per Prodi (Motivational)
        ranking_gaji = Prodi.objects.annotate(
            max_gaji=Max('alumni__surveys__gaji')
        ).exclude(max_gaji__isnull=True).order_by('-max_gaji')[:10] # Top 10

        context = {
            'is_admin': False,
            'pie_data': pie_data,
            'ranking_gaji': ranking_gaji
        }
        return render(request, 'statistik/dashboard.html', context)

    # --- LOGIC ADMIN (Full Detail + Filter + Export) ---
    else:
        # Filter
        tahun_filter = request.GET.get('tahun')
        prodi_filter = request.GET.get('prodi')
        
        alumni_qs = Alumni.objects.all()
        if tahun_filter: alumni_qs = alumni_qs.filter(tahun_lulus=tahun_filter)
        if prodi_filter: alumni_qs = alumni_qs.filter(prodi_id=prodi_filter)

        # Grafik 1: Status Bekerja
        stats_bekerja = alumni_qs.values('status_bekerja').annotate(total=Count('id'))
        pie_data = [0, 0]
        for item in stats_bekerja:
            if item['status_bekerja']: pie_data[0] = item['total']
            else: pie_data[1] = item['total']

        # Grafik 2: Kesesuaian (Dari data survey yang terfilter alumni-nya)
        survey_qs = Survey.objects.filter(alumni__in=alumni_qs)
        stats_kesesuaian = survey_qs.values('kesesuaian').annotate(total=Count('id'))
        bar_labels = [item['kesesuaian'] for item in stats_kesesuaian]
        bar_data = [item['total'] for item in stats_kesesuaian]

        # Tabel Gaji Tertinggi
        ranking_gaji = Prodi.objects.annotate(
            max_gaji=Max('alumni__surveys__gaji')
        ).exclude(max_gaji__isnull=True).order_by('-max_gaji')

        context = {
            'is_admin': True,
            'pie_data': pie_data,
            'bar_labels': bar_labels,
            'bar_data': bar_data,
            'ranking_gaji': ranking_gaji,
            'prodi_list': Prodi.objects.all(),
            'tahun_list': Alumni.objects.values_list('tahun_lulus', flat=True).distinct()
        }
        return render(request, 'statistik/dashboard.html', context)

@login_required
@user_passes_test(is_admin)
def export_pdf(request):
    # Setup Buffer & Doc
    response = HttpResponse(content_type='application/pdf')
    # Tambahkan Timestamp di nama file
    filename = f"Laporan_Tracer_{datetime.date.today()}.pdf"
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    elements = []
    styles = getSampleStyleSheet()

    # --- 1. HEADER & FILTER INFO ---
    elements.append(Paragraph("Laporan Eksekutif Tracer Study", styles['Title']))
    
    # Menampilkan Info Filter yang sedang aktif
    filter_tahun = request.GET.get('tahun', 'Semua Angkatan')
    filter_info = f"Filter Data: Tahun Lulus {filter_tahun} | Dicetak: {datetime.date.today().strftime('%d-%m-%Y')}"
    elements.append(Paragraph(filter_info, styles['Normal']))
    elements.append(Spacer(1, 20))

    # Ambil Data Statistik (Sesuai Filter jika ada logic filter di URL export)
    # Catatan: Idealnya parameter filter dikirim via GET ke url export
    stats = get_statistik_data(request.GET.get('tahun')) 

    # --- 2. GRAFIK VISUAL ---
    elements.append(Paragraph("<b>A. Visualisasi Data</b>", styles['Heading2']))
    
    # Layout Table untuk Grafik (Supaya rapi bersanding atau atas bawah)
    # Kita taruh Pie Chart
    d_pie = Drawing(width=400, height=150)
    pc = Pie()
    pc.x = 100
    pc.y = 25
    pc.width = 100
    pc.height = 100
    pc.data = stats['pie_data'] 
    pc.labels = ['Bekerja', 'Belum']
    pc.slices[0].fillColor = colors.green
    pc.slices[1].fillColor = colors.red
    d_pie.add(pc)
    elements.append(Paragraph("1. Status Pekerjaan Alumni", styles['Heading3']))
    elements.append(d_pie)
    
    # Bar Chart
    if stats['bar_data']:
        d_bar = Drawing(width=400, height=160)
        bc = VerticalBarChart()
        bc.x = 50
        bc.y = 30
        bc.height = 100
        bc.width = 300
        bc.data = [stats['bar_data']]
        bc.categoryAxis.categoryNames = stats['bar_labels']
        bc.bars[0].fillColor = colors.blue
        bc.valueAxis.valueMin = 0
        d_bar.add(bc)
        elements.append(Paragraph("2. Tingkat Kesesuaian Bidang Studi", styles['Heading3']))
        elements.append(d_bar)

    elements.append(Spacer(1, 20))

    # --- 3. RINGKASAN ANGKA PENTING (Executive Summary) ---
    # Ini yang diminta di Image 903400
    elements.append(Paragraph("<b>B. Ringkasan Angka Penting</b>", styles['Heading2']))
    
    # Hitung data summary
    total_responden = sum(stats['pie_data'])
    jml_bekerja = stats['pie_data'][0]
    persen_bekerja = (jml_bekerja / total_responden * 100) if total_responden > 0 else 0
    
    # Hitung rata-rata gaji global (dari data yang difilter)
    # Kita query ulang sebentar untuk summary gaji yang akurat sesuai filter
    alumni_qs = Alumni.objects.all()
    if request.GET.get('tahun'):
        alumni_qs = alumni_qs.filter(tahun_lulus=request.GET.get('tahun'))
    avg_gaji_val = Survey.objects.filter(alumni__in=alumni_qs).aggregate(Avg('gaji'))['gaji__avg'] or 0
    
    summary_data = [
        ['Indikator', 'Nilai'],
        ['Total Responden', f"{total_responden} Alumni"],
        ['Persentase Bekerja', f"{persen_bekerja:.1f}%"],
        ['Rata-rata Gaji', f"Rp {avg_gaji_val:,.0f}"],
    ]

    t_summary = Table(summary_data, colWidths=[200, 200])
    t_summary.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (1, 0), colors.lightgrey),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('ALIGN', (1, 1), (1, -1), 'RIGHT'), # Rata kanan untuk angka
    ]))
    elements.append(t_summary)
    elements.append(Spacer(1, 20))

    # --- 4. TABEL DETAIL DATA ---
    elements.append(Paragraph("<b>C. Detail Data Survey (Terbaru)</b>", styles['Heading2']))
    
    data_table = [['Nama', 'Perusahaan', 'Posisi', 'Gaji', 'Kesesuaian']]
    # Filter survey sesuai request tahun juga
    surveys = Survey.objects.select_related('alumni').all()
    if request.GET.get('tahun'):
        surveys = surveys.filter(alumni__tahun_lulus=request.GET.get('tahun'))
    
    surveys = surveys.order_by('-created_at') # Ambil semua, atau limit jika terlalu banyak
    
    for s in surveys:
        gaji_fmt = f"Rp {s.gaji:,.0f}" if s.gaji else "-"
        # Truncate nama jika kepanjangan biar tabel muat
        nama_alumni = s.alumni.nama[:20] + '...' if len(s.alumni.nama) > 20 else s.alumni.nama
        data_table.append([nama_alumni, s.perusahaan, s.bidang_pekerjaan, gaji_fmt, s.kesesuaian])

    table = Table(data_table, colWidths=[120, 100, 100, 80, 80])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8), # Font lebih kecil biar muat
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
    ]))
    
    elements.append(table)
    
    doc.build(elements)
    pdf = buffer.getvalue()
    buffer.close()
    response.write(pdf)
    return response