# alumni/forms.py
from django import forms
from .models import Alumni, Prodi

class AlumniForm(forms.ModelForm):
    class Meta:
        model = Alumni
        # Tambahkan 'email' ke fields
        fields = ['nim', 'nama', 'email', 'tahun_lulus', 'prodi']
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['prodi'].queryset = Prodi.objects.all().order_by('fakultas__nama', 'nama')